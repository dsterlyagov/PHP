<?php
/**
 * Created by PhpStorm.
 * User: Дима
 * Date: 22.04.2019
 * Time: 11:08
 */
function debug($arr){
    echo'<pre>'.print_r($arr).'</pre>';
}