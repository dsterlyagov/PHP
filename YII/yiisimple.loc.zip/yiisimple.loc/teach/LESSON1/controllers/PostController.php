<?php
/**
 * Created by PhpStorm.
 * User: Дима
 * Date: 19.04.2019
 * Time: 14:19
 */

namespace app\controllers;


class PostController extends AppController
{
public function actionIndex($name){
    $hello = 'Привет мир!!!';
    return $this->render('index', compact('hello','name'));
}
public function actionTest(){
    return "Test";
}
}