<?php
/**
 * Created by PhpStorm.
 * User: Дима
 * Date: 22.04.2019
 * Time: 9:37
 */

namespace app\models;
use yii\db\ActiveRecord;


class Post extends ActiveRecord
{
    public static function tableName(){
        return 'post';
    }
}