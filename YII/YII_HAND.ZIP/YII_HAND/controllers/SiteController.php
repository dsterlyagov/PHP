<?php
/**
 * Created by PhpStorm.
 * User: Дима
 * Date: 23.05.2019
 * Time: 14:46
 */

namespace app\controllers;


use yii\web\Controller;

class SiteController extends Controller
{
public function actionIndex(){
    return $this->render('index');
}

}