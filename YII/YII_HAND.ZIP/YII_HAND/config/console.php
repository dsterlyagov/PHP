<?php
/**
 * Created by PhpStorm.
 * User: Дима
 * Date: 23.05.2019
 * Time: 14:18
 */
return[
    'id' => 'yiihand-console',
    'basePath' => dirname(__DIR__),
    'components' => [
        'db' => require (__DIR__.'/db.php')
    ]
];