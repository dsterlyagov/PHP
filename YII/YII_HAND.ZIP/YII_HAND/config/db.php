<?php
/**
 * Created by PhpStorm.
 * User: Дима
 * Date: 31.05.2019
 * Time: 12:41
 */
return[
    'class' => '\yii\db\Connection',
    'dsn' =>'mysql:host=localhost;dbname=yiihand',
    'username' => 'root',
    'password' => ''
];