<?php
/**
 * Created by PhpStorm.
 * User: Дима
 * Date: 23.05.2019
 * Time: 14:18
 */
return[
    'id' => 'yiihand.loc',
    'basePath' => realpath(__DIR__.'/../'),
    'bootstrap' => ['debug'],
    'components' =>[
        'urlManager' => [
            'enablePrettyUrl' =>true,
            'showScriptName' => false
        ],
        'request' => [
            'cookieValidationKey' => 'password',
            'baseUrl' => '',
        ],
        'db' => require (__DIR__.'/db.php'),
        'user' => ['identityClass' => 'app\models\UserIdentity']
    ],

    'modules' =>[
        'debug' => 'yii\debug\Module'
    ]
];